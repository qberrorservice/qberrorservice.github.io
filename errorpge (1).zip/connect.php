<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error page with Progress Bar</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            color: #333;
            font-weight: normal;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 120vh;
        }

        header {
            background-color: #333;
            padding: 20px 0;
            text-align: center;
        }

        header img {
            height: 60px;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .progress-container progress {
            width: 1000px; /* Adjust the width as needed */
            height: 40px;
            border-radius: 20px;
            appearance: none;
            -webkit-appearance: none;
            background-color: #eee;
            margin-bottom: 10px;
            margin-left:120px;
        }

        .progress-container progress::-webkit-progress-bar {
            background-color: #eee;
            border-radius: 20px;
        }

        .progress-container progress::-webkit-progress-value {
            background-color: #4CAF50;
            border-radius: 20px;
        }

        .progress-container progress::-moz-progress-bar {
            background-color: #4CAF50;
            border-radius: 20px;
        }

        .progress-label {
            color: #000;
            font-weight: bold;
            margin-left:600px;
        }

        .error-container {
            max-width: 500px;
            margin: 20px;
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            height: 380px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            transition: box-shadow 0.3s ease-in-out;
            margin-left: -400px;
        }

        .error-container:hover {
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.4);
        }

        h2, h3, h4 {
            text-align: center;
            margin: 20px 0;
        }

        span {
            color: #e44d26;
        }

        p {
            margin-top: 10px;
            text-align: center;
            font-size: 18px;
        }

        .quote {
            color: black;
            font-size: 16px;
        }

        .contact-support {
            text-align: center;
            margin-top: 20px;
        }

        .phone-icon {
            font-size: 24px;
            margin-right: 10px;
        }

        .contact-support a {
            color: #1e891a;
            text-decoration: none;
            font-weight: bold;
        }

        .image-container {
            margin-top: 100px; /* Adjust the margin-top as needed */
            margin-left: -520px; /* Adjust the left margin as needed */
        }

        .image-container img {
            max-width: 120%; /* Adjust the max-width as needed */
            height: auto; /* Maintain aspect ratio */
            border-radius: 12px; /* Add border radius if desired */
        }

        .loading-label {
            text-align: center;
            font-size: 20px;
            margin-bottom: 10px;
            color: #333;
            margin-left:-650px;
        }

        /* New CSS for logo */
        .logo {
            width: 200px; /* Adjust the width as needed */
            margin-right: 50px; /* Adjust the right margin as needed */
            align-self: flex-end; /* Align to the right side */
        }

    </style>
</head>
<body>

<div class="container">
    <!-- New logo here -->
    <img src="quickbooks-high-resolution-logo-transparent.png" alt="Your Logo" class="logo">
    <div class="loading-label">Loading your account...</div>
    <div class="progress-container">
        <progress id="progress" value="0" max="100"></progress>
        <div class="progress-label">0%</div>
    </div>

    <h2><img src="error logo.png" alt="Little Logo" width="39px" ><span style="color: #FF0000;"> Sorry, system Failed to loading Your Account - Call for Immediate Assistance!</span></h2>

    <div class="error-container">
        <h2 style="font-size: 23px;">Cannot Download Setup file for this Account</h2>
        <h3 style="font-size: 19px;"><span style="color: #FF0000;">Encountered an Unexpected Error – 00×6523 with the QB Tool Hub</span></h3>

        <p style="font-size: 18px;">May be your System is unable to locate your setup account, it happens due to many reasons. </p>

        <p style="font-size: 18px;">Need Quick Help? Call Us Right Away for Immediate Assistance!</p>

        <div class="contact-support">
            <div class="phone-icon">&#9742;</div>
            <p style="font-size: 20px;">Contact Support: <a href="tel:+12345678900">+1 (234) 567-8900</a></p>

            <p class="quote">"We got your error report, and our support team will give you a call in a few minutes to help you out. Thanks for your patience!"</p>
        </div>
    </div>
</div>

<div class="image-container">
    <img src="Migration_Motion_Fin2.gif" alt="Image Description">
</div>

<div class="separator"></div>

<script>
    function updateProgress() {
        var progressBar = document.getElementById('progress');
        var progressLabel = document.querySelector('.progress-label');

        // Update the progress value (any value between 0 and 40)
        progressBar.value += 1;

        // Update the progress label
        progressLabel.textContent = progressBar.value + '%';

        // Check if the progress is at 40%
        if (progressBar.value >= 40) {
            // Stop updating progress
            clearInterval(progressInterval);
        }
    }

    // Update every 100 milliseconds (adjust as needed for desired speed)
    var progressInterval = setInterval(updateProgress, 100);
</script>

</body>
</html>
